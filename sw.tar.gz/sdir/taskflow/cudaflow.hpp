#pragma once

// taskflow.hpp 
// ^
// |
// cudaflow.hpp

#include "taskflow.hpp"
#include "cuda/cuda_flow.hpp"

/**
@file cudaflow.hpp
@brief main cudaFlow include file
*/
